#!/bin/bash
python3 -m pip install httpx bs4 PyQt6 discord requests selenium ujson webdriver_manager