**Advertisement**

Do you want to join a chill Discord server* with nearly zero rules, a growing community, and free nitro giveaways? [Join us today!](https://discord.gg/zNVYXUvTeu)

**This Discord server is not affiliated with the-cult-of-integral nor this project.*

---

![celebrating-four-years](https://github.com/user-attachments/assets/651d365a-3ad4-4a80-93ea-ef68297b5467)

![Discord Raidkit Banner](https://user-images.githubusercontent.com/98130822/235323678-64a0ac47-b491-498f-98c0-1a113461336b.png)

[![Made by the-cult-of-integral](https://github.com/user-attachments/assets/23db8e79-ad8f-48c4-87cf-f299444d513a)](https://github.com/the-cult-of-integral)
![Made With Python](https://forthebadge.com/images/badges/made-with-python.svg)
![Built With Love](http://forthebadge.com/images/badges/built-with-love.svg)

![GitHub Contributors](https://img.shields.io/github/contributors/the-cult-of-integral/discord-raidkit)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=shields)](http://makeapullrequest.com)
![GitHub Issues](https://img.shields.io/github/issues/the-cult-of-integral/discord-raidkit)
![GitHub Pull Requests](https://img.shields.io/github/issues-pr/9P9/Discord-QR-Token-Logger)
![Maintencance](https://img.shields.io/maintenance/yes/2024)
![GitHub Commit Activity](https://img.shields.io/github/commit-activity/m/the-cult-of-integral/discord-raidkit)

Discord Raidkit is an open-source, forever free tool that allows you to raid and destroy Discord servers via Discord bots, as well as compromise Discord accounts.

---

[Have a feature suggestion? Make one here!](https://github.com/the-cult-of-integral/discord-raidkit/discussions/categories/ideas)

![Discord Raidkit 2.5.0](https://github.com/user-attachments/assets/2b58f758-a247-422f-b5e2-4fef5bb776fc)

---

## Features

- **Attack Discord Servers** - this application can be used to perform a variety of attacks on Discord Servers, including nuking, raiding, and permissions escalation for given members.

- **Attack Discord Users** - this application can also be used to target users. You can gather user information, including banking, log into accounts without a password, and nuke accounts.
 
- **Adapted for social-engineering** - unlike other tools of this nature, that presume you have already smuggled your way into a server, Discord Raidkit provides many slash genuine commands, that may be used to convince server owners that a bot is legitimate.

- **Longevity** - this toolkit has been maintained since August 3rd, 2020 - four years since its creation. It usually stays up-to-date with any major features, such as slash commands, which, of course, did not exist when this project first started. The latest version was released August 8th, 2024.

## Tools

- **Horus** allows you to control a Discord bot, providing ten malicious commands. However, unlike other nuking tools, Horus also has several non-malicious slash commands, determined by which *Raider Type* you chose. 
  - *Anubis* - this type provides a moderation suite of slash commands, to help you convince administrators to add the bot.
  - *Qetesh* - this type provides an NSFW suite of slash commands for the top 25 sexual kink, to help you convince the typical Discord moderator to add the bot.

- **Osiris** is the account manager of Discord Raidkit. Using Osiris, you can save the information of an account, login to an account using either Chrome, Firefox, or Microsoft Edge, or you can fully nuke an account, deleting channels, guilds, friends, and connections, deauthorizing applications, removing hype squad, and PATCHing various account settings.

## Installation
The installation of Discord Raidkit is incredibly simple:
1. Head over to [the latest release](https://github.com/the-cult-of-integral/discord-raidkit/releases/latest).
2. Download the executable zip.
3. Extract and run the executable in its directory. Make sure to run the executable in the same directory as `_internal`.

**Notice:** Some anti-malware may flag this project as harmful — especially any files that relate to Osiris, as this tool targets users. If you are having issues with anti-malware constantly getting in the way of using this tool, you can create a folder, add that folder to the anti-malwares list of excluded search/scan locations, then place the Discord Raidkit files in said folder. This should allow Discord Raidkit to function correctly without interferance. **Do not randomly exclude every location on your computer!**

## How to use Discord Raidkit
To learn more about how to use Discord Raidkit, feel free to [read the Wiki page!](https://github.com/the-cult-of-integral/discord-raidkit/wiki/Home/)

----

## ️⚠️ **Disclaimer** 📖

This program has been created for educational purposes, highlighting the dangers of social engineering.

**By using this program, you agree that I am in no way responsible for your usage of this program.**

---

<p align="left">
  <strong>Views</strong> (as of 24/09/2022)<br><br>
  <img src="https://profile-counter.glitch.me/discord-raidkit/count.svg" />
</p>
